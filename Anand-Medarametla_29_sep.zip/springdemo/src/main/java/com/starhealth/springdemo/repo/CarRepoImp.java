package com.starhealth.springdemo.repo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.starhealth.springdemo.beans.Car;

@Repository
public class CarRepoImp implements CarRepo {

	Connection con = DbCon.getCon();

	@Override
	public int addCar(Car car) {
		int count = 0;

		try {

			String query = "insert into carsInfo(id, name, carType, price) values(?,?,?,?)";

			PreparedStatement pt = con.prepareStatement(query);

			pt.setInt(1, car.getId());
			pt.setString(2, car.getName());
			pt.setString(3, car.getCarType());
			pt.setDouble(4, car.getPrice());

			count = pt.executeUpdate();

			System.out.println(count + "Cars Added..");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return count;
	}


	public int updateCar(Car car) {
		// TODO Auto-generated method stub
		int count = 0;

		try {

			String query = "update carsInfo set name=?, carType=?, price=? where id=?";

			PreparedStatement pt = con.prepareStatement(query);

			pt.setInt(1, car.getId());
			pt.setString(2, car.getName());
			pt.setString(3, car.getCarType());
			pt.setDouble(4, car.getPrice());

			count = pt.executeUpdate();

			System.out.println(count + "Cars Added..");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return count;
	}

	@Override
	public List<Car> getAllCarData() {

		List<Car> list = new ArrayList<Car>();

		String query = "select * from carsInfo";

		try {
			PreparedStatement pt = con.prepareStatement(query);

			ResultSet rs = pt.executeQuery();

			while (rs.next()) {

				Car car = new Car();

				pt.setInt(1, car.getId());
				pt.setString(2, car.getName());
				pt.setString(3, car.getCarType());
				pt.setDouble(4, car.getPrice());

				list.add(car);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

}
