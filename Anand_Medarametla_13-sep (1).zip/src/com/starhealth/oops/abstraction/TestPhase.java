package com.starhealth.oops.abstraction;
import java.util.Scanner;

public class TestPhase {
	
	public static void main(String[] args) {
		
		System.out.println("1.Deposit");
		System.out.println("2.Withdraw");
		
		
		Scanner sc = new Scanner(System.in);
		
		int key = sc.nextInt();
		
		IceBank obje = UtilBank.getObject();
		
		switch (key) {
		case 1:
			obje.deposit();
			break;
		case 2:
			obje.withdraw();
			break;
		default:
			System.out.println("INVALID");
		}
	}

}
