package com.springbootTraining.service;

import java.util.List;

import com.springbootTraining.entity.Customer;

public interface CustomerService {
	public Customer addCustomer(Customer customer) ;
	
	public Customer updateCustomer(Customer customer);
	public Customer selectCustomerById(int id);
	public void deleteCustomerById(int id);
	public List<Customer> selectAllCustomers();
	public Customer selectByCustomerName(String customerName);
	public List<Customer> selectSortedCustomerName();

}
