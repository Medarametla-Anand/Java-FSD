package com.starhealth.springrestapi.excep;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

public class Excephand {

	@ExceptionHandler(value = NullPointerException.class)
	@ResponseStatus(reason = "Null value found, excerption occured")
	public void nullPointerhandler() {

	}

	@ExceptionHandler(value = ArithmeticException.class)
	@ResponseStatus(reason = "ID not found...")
	public void arithmaticHandler() {

	}

}
