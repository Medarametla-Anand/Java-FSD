package com.starhealth.springdemo.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Car {
	
	private int id;
	private String name;
	private String carType;
	private double price;

}
