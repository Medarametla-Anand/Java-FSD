package com.starhealth.springdemo.repo;

import java.util.List;

import com.starhealth.springdemo.beans.Car;

public interface CarRepo {
	
	
	
	public List<Car> getAllCarData();

	public int addCar(Car car);
	public int updateCar(Car car);

}
