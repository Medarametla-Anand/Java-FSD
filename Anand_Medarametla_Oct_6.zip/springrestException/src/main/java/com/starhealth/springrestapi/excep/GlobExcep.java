package com.starhealth.springrestapi.excep;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobExcep {

	@ExceptionHandler(value=Exception.class)
	public ResponseEntity<String> handlerr() {

		return new ResponseEntity<String>("Some error is there, Please check...", HttpStatus.NOT_FOUND);

	}

}
