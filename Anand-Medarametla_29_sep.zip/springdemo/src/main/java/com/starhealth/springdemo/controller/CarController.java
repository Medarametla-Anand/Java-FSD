package com.starhealth.springdemo.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.starhealth.springdemo.beans.Car;
import com.starhealth.springdemo.serv.CarService;

@Controller
@RequestMapping("/api/v1/car")
public class CarController {
	
	
	
	@Autowired
	CarService serv;
	
	@RequestMapping(value="/add", method = RequestMethod.POST)
	@ResponseBody
	public String addInfo(Car car) {
		
		int count = serv.addCar(car);
		
		return count+ "Records added successfully...";
		
		
	}
	
	@RequestMapping(value="/update",method=RequestMethod.POST)
	@ResponseBody
	public String updateCar(Car car) {
		int count=serv.updateCar(car);
		
		return count+ "Record Updated Succesfully";
		
	}
	
	
	@RequestMapping("/all")
	public String getAllCarData(HttpSession session) {
		
	List<Car> list = serv.getAllCarData();
	
	session.setAttribute("car", list);
	return "success";
	
	
	}
	
}
