package com.starhealth.oops.polymorphism;

public class MethodOverload {
	
	public void display(int a, int b) {
		
		System.out.println(a+b);
	}
	
	public void display(String s) {
		System.out.println(s);
		
	}
	public void display() {
		System.out.println("No Arguement");
		
	}
	
	public static void main(String[] args) {
		
		int id1 = 200;
		int id2 = 100;
		String name = "Anand ";
		
		MethodOverload obj = new MethodOverload();
		
		obj.display();
		obj.display(id1,id2);
		obj.display(name);
		
	}

}
