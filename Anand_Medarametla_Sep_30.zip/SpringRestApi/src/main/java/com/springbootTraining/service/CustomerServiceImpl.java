package com.springbootTraining.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbootTraining.entity.Customer;
import com.springbootTraining.repository.CustomerRepo;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerRepo customerRepo;

	@Override
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepo.save(customer);
		

	}

	@Override
	public Customer updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepo.save(customer);


	}

	@Override
	public Customer selectCustomerById(int id) {
		// TODO Auto-generated method stub
		return customerRepo.findById(id).orElse(new Customer());

	}

	@Override
	public void deleteCustomerById(int id) {
		// TODO Auto-generated method stub
		customerRepo.deleteById(id);

	}

	@Override
	public List<Customer> selectAllCustomers() {
		// TODO Auto-generated method stub
		return customerRepo.findAll();
	}

	@Override
	public Customer selectByCustomerName(String customerName){
		// TODO Auto-generated method stub
		return customerRepo.findByCustomerName(customerName);
	}

	public List<Customer> selectSortedCustomerName(){
		return customerRepo.findBySortedCustomerName();
	}
}
