package com.starhealth.oops.inheritance;

public class Test3 extends Child{

	public static void main(String[] args) {
		
		
		Parent p = new Child();
		
	    System.out.println(p.totalMoney);
		
		p.methodOne();
		p.methodTwo();
		
		
		

	}

}
