package com.springbootTraining.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.springbootTraining.entity.Customer;

public interface CustomerRepo extends JpaRepository<Customer,Integer> {
	public Customer findByCustomerName(String customnerName);
	
	@Query("select customer from Customer customer order by customerName desc ")
	public List<Customer> findBySortedCustomerName();
	
	
	

}
