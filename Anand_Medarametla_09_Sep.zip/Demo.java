package Practice;

public class Demo {
	
	

	public static void main(String[] args) {
		
		int id = 22;
		byte num = 1;
		short sNo = 5;
		double avg = 45.0;
		long score = 46000;
		float sum= 50.5f;
		char grade = 'A';
		boolean result = false;
		
		String name = "Anand";
		
		System.out.println(id);
		System.out.println(num);
		System.out.println(sNo);
		System.out.println(avg);
		System.out.println(score);
		System.out.println(score);
		System.out.println(sum);
		System.out.println(grade);
		System.out.println(result);

	}

}
