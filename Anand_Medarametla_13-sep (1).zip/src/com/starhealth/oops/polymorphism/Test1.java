package com.starhealth.oops.polymorphism;

public class Test1 {
	
	public static void main(String[] args) {
		
		MethodOverriding obje = new MethoOverrideChild();
		
		obje.show();
		
		System.out.println(obje.Mes());
		
	}
	

}
