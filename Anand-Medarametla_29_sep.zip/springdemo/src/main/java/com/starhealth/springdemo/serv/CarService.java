package com.starhealth.springdemo.serv;

import java.util.List;

import com.starhealth.springdemo.beans.Car;

public interface CarService {

	public int addCar(Car car);
	public int updateCar(Car car);

	public List<Car> getAllCarData();

}
