package com.starhealth.oops.abstraction;

public class ImpTwo extends ImpOne{

	@Override
	public void withdraw() {
		
		
		System.out.println("Withdraw Successful !!");
		
	}
	
	
	
	

}
