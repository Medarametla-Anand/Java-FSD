package com.springbootTraining.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springbootTraining.entity.Customer;
import com.springbootTraining.service.CustomerService;

@RestController
@RequestMapping("api/v1/customers")
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	
	
		@PostMapping("/add")
		public  Customer addCustomer(@RequestBody Customer customer) {
			
			
			return customerService.addCustomer(customer);
			
		}
		
		
		@PutMapping("/update")
		public Customer  updateCustomer(@RequestBody Customer customer) {
			
			
			return customerService.updateCustomer(customer);
			
		}
		
		@DeleteMapping("/delete/{id}")  // http://localhost:8080/api/v1/employees/delete/101
		public String deleteCustomerById(@PathVariable int id) {
			
			customerService.deleteCustomerById(id);
			 
			 return "Recored Deleted Successfully";
			
		}
		
		
		@GetMapping("/get/{id}")
		public Customer  selectEmployeeById(@PathVariable  int id) {    // http://localhost:8080/api/v1/employees/get/101
			
			
			return customerService.selectCustomerById(id);
			
			
		}
		
		
		@GetMapping("/getall")
		public List<Customer>  selectAllCustomers(){  // http://localhost:8080/api/v1/employees/getall
			
			
			return customerService.selectAllCustomers();
			
		}
		
		@GetMapping("/get/CustomerName/{customerName}")
		public Customer selectByCustomerName(@PathVariable String customerName) {
			return customerService.selectByCustomerName(customerName);
		}
		
		
		@GetMapping("/get/SortedCustomerName")
		public List<Customer> selectSortedCustomerName(){
			return customerService.selectSortedCustomerName();
		}
		
	

}
