package com.starhealth.oops.abstraction;

public abstract class ImpOne implements IceBank{

	@Override
	public void deposit() {
		
		System.out.println("Deposit Success !!");
		
	}

	
	
	

}
