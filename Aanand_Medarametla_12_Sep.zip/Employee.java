package com.starhealth.variables;

public class Employee {
	
private	int empId;
private	String empName;
private	float empTotal;
private	double empFee;
	
	static int empContact = 99999;

	
	public Employee(int empId, String empName, float empTotal, double empFee) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empTotal = empTotal;
		this.empFee = empFee;
	}






	public int getEmpId() {
		return empId;
	}






	public void setEmpId(int empId) {
		this.empId = empId;
	}






	public String getEmpName() {
		return empName;
	}






	public void setEmpName(String empName) {
		this.empName = empName;
	}






	public float getEmpTotal() {
		return empTotal;
	}






	public void setEmpTotal(float empTotal) {
		this.empTotal = empTotal;
	}






	public double getEmpFee() {
		return empFee;
	}






	public void setEmpFee(double empFee) {
		this.empFee = empFee;
	}






	public Employee() {
		super();
	
	}




}
