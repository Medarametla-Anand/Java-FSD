package com.starhealth.oops.polymorphism;

public class MethoOverrideChild extends MethodOverriding {

	@Override
	public void show() {

		System.out.println("I am Coming from Child Class !!");
	}

	
	@Override 
	public String Mes() {

		return " Child Class !!";
	}

}
