package com.starhealth.oops.inheritance;

public class Parent {

	int totalMoney = 30000;

	String bikeName = "Ktm";

	public void methodOne() {

		System.out.println("Parent Class Method !!");
		System.out.println(bikeName);

	}

	public void methodTwo() {

		System.out.println(bikeName);
	}

}
